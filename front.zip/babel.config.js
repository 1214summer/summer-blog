module.exports = {
    presets: [
      [
        '@babel/preset-env',
        {
          modules: false
        }
      ],
      '@babel/preset-react', // 需要放在@babel/preset-env后面，先处理
      '@babel/preset-typescript'
    ],
    plugins: [
      [
        '@babel/plugin-transform-runtime',
        {
          corejs: {
            version: 3,
            proposals: true
          }
        }
      ],
      ['@babel/plugin-syntax-dynamic-import'],
      [
        'babel-plugin-import',
        {
          libraryName: '@arco-design/web-react',
          libraryDirectory: 'es',
          camel2DashComponentName: false,
          style: true // 样式按需加载
        }
      ],
      [
        'babel-plugin-import',
        {
          libraryName: '@arco-design/web-react/icon',
          libraryDirectory: 'react-icon',
          camel2DashComponentName: false
        },
        'babel-plugin-import-2'
      ]
    ]
  };
  