## Summer React Vite
学习vite之后搭建的项目，仅供个人开发开箱即用
一个自己基于Vite搭建的react手架，配置了相关模块，添加了常用功能，便于yihoureact新项目的搭建

此脚手架集成了react+react-router-dom-typescript+redux+sass+commitlint+eslint+antd+ahooks
可以省去繁琐的配置过程，开箱即用

### 使用
安装依赖
```
npm install
```
开发依赖
```
npm run dev
 ```
生产依赖
```
npm run build
```
