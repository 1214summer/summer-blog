//博客云环境ID
export const env = "cloud1-2gbimj2k566ff366";

//Github地址
export const githubUrl = "https://github.com/1214summer";

// 博客运行起始日
export const time = "2024-12-14 14:00:00";
//网站名字
export const siteTitle = "wuli summer"
//卡片背景图
export const cardUrl = "https://cdn.jsdelivr.net/gh/1214summer/PicGo_Img@master/avatar.png";

// 说说头像图
export const avatarImg = "https://cdn.jsdelivr.net/gh/1214summer/PicGo_Img@master/avatar.png";

// 微信二维码地址
export const weChatQRCode = "https://img.lzxjack.top/202203302344287.webp";
// QQ二维码地址
export const QQ_QRCode = "https://img.lzxjack.top/202203302344487.webp";

export const juejinUrl = "https://juejin.cn/user/910845591685368"



//首页文章分页
export const homeSize = 8;
export const msgSize = 10;
export const detailPostSize = 10;

// 数据缓存时间
export const staleTime = 180000;
export const siteCountStale = 300000;

//个人信息
export const myName = "summer";
export const myLink= "http://127.0.0.1:8080";
export const myAvatar = "https://img.lzxjack.top/202203302154224.webp";
export const myDescr = "捍卫自己的系统";
export const myEmail = "3050368564@qq.com";
export const adminUid = "41fcc65978324a8db4048993dfc0a9df";
export const QQ = "3050368564";
export const myAvatar70 = "https://img.lzxjack.top/202203302156259.webp";
