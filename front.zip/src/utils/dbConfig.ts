/* eslint-disable no-unused-vars */
export enum DB {
  About = 'about',
  Msg = 'comments',
  Article = 'articles',
  Class = 'classes',
  Drafe = 'drafts',
  Link = 'links',
  Log = 'logs',
  Notice = 'notice',
  Say = 'says',
  Show = 'shows',
  Count = 'siteCount',
  Tag = 'tags'
}



