// 当前环境
export const nowEnv: 'test' | 'prod' = 'prod';
// export const nowEnv: 'test' | 'prod' = 'prod';
