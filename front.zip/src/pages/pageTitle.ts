export enum Title {
    Articles = '所有文章',
    Classes = '分类',
    Tags = '标签',
    Say = '碎碎念~~',
    Msg = '留言板',
    Link = '友情链接',
    Show = '小作品',
    Log = '建站日志',
    About = '关于'
  }
  