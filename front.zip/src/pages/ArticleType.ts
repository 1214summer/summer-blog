export interface ArticleType {
    _id: string;
    title: string;
    date: number;
    titleEng: string;
}