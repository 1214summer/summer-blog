import React from 'react';

import s from './index.module.scss';

const Divider: React.FC = () => <div className={s.divider} />;

export default Divider;