declare module '*.css' {
  const style: { [className: string]: string };
  export default style;
}

declare module '*.scss' {
  const style: { [className: string]: string };
  export default style;
}

declare module '*.less' {
  const style: { [className: string]: string };
  export default style;
}
